class ImageConstant {
  static String imgLogo1 = 'assets/images/img_logo1.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgImage5 = 'assets/images/img_image5.png';

  static String imgMessage1 = 'assets/images/img_message_1.svg';

  static String imgVectorErrorcontainer =
      'assets/images/img_vector_errorcontainer.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgImage4 = 'assets/images/img_image4.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
